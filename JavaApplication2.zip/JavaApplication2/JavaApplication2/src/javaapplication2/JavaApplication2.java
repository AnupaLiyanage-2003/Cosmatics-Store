/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author anupa
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        progress_bar pb = new progress_bar();
        pb.setVisible(true);
        try
        {
            for(int x=0;x<=100;x++){
                Thread.sleep(50);
                pb.lblloading.setText(Integer.toString(x)+"%");
                pb.jProgressBar.setValue(x);
            }
            welcome dbconn = new welcome();
            dbconn.setVisible(true);
            pb.setVisible(false);
            
        }catch(Exception ex){
        }  
    
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
